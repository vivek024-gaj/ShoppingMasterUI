export class Application {
    id: number;
    name: string;

}
