export class Group {
  id: number;
  name: String;
}
