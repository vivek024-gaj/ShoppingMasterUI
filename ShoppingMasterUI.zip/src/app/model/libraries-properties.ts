export class LibrariesProperties {

    id: number;
    libraryId: number;
    attrKey: string;
    attrValue: string;
}
