export class Libraries {
    id: number;
    name: string;
}
