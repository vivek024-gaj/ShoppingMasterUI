export class ManageRole {
  id: number;
  roleId: string;
  groupId: string;
  resourceId: string;
  resourceURI: string;
  group: string;
}
