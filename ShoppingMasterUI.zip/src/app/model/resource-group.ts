export class ResourceGroup {
  id: number;
  resourceGroupName: string;
  menuPlacement: number;
}
