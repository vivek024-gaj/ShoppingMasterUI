export class Resource {
  id: number;
  parentId: string;
  groupId: string;
  resourceUrl: string;
  resourceName: string
}
