export class ResponseMessage {
  success: boolean;
  message: string;
  error: string;
  path: string;
}
