export class User {
  id: number;
  name: string;
  email: string;
  role: string;
  status: string;
  token?: User;
  designation: string;
}
