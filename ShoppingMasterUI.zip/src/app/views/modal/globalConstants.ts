export const globalConstants = {

    deleteDataTitle: "Delete Confirmation ",
    deleteDataMsg: "Are you sure to Delete ",
    approveDataTitle: "Approve Confirmation ",
    approveDataMsg: "Are you sure to Approve ",
    finalizeDataTitle: "Finalize Confirmation ",
    finalizeDataMsg: "Are you sure to Finalize ",
    rejectDataTitle: "Reject Confirmation ",
    rejectDataMsg: "Are you sure to Reject ",


}