import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-docker-container',
  templateUrl: './add-docker-container.component.html',
  styleUrls: ['./add-docker-container.component.scss']
})
export class AddDockerContainerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
