import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-vm-config',
  templateUrl: './add-vm-config.component.html',
  styleUrls: ['./add-vm-config.component.scss']
})
export class AddVmConfigComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
