import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-vm',
  templateUrl: './add-vm.component.html',
  styleUrls: ['./add-vm.component.scss']
})
export class AddVmComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
